package com.badlogic.androidgames.framework;

public interface Audio
{

	public Music newMusic(String fileName);
	public Sound newSound(String fileName);
	
}
