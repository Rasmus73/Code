package com.badlogic.androidgames.AwesomeExample;

import com.badlogic.androidgames.framework.Audio;
import com.badlogic.androidgames.framework.FileIO;
import com.badlogic.androidgames.framework.Game;
import com.badlogic.androidgames.framework.Graphics;
import com.badlogic.androidgames.framework.Input;
import com.badlogic.androidgames.framework.Screen;

import android.app.Activity;

public class AndroidGame extends Activity implements Game
{	

	public Input getInput() {
		// TODO Auto-generated method stub
		return null;
	}

	public FileIO getFileIO() {
		// TODO Auto-generated method stub
		return null;
	}

	public Graphics getGraphics() {
		// TODO Auto-generated method stub
		return null;
	}

	public Audio getAudio() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setScreen(Screen screen) {
		// TODO Auto-generated method stub
		
	}

	public Screen getCurrentScreen() {
		// TODO Auto-generated method stub
		return null;
	}

	public Screen getStartScreen() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
